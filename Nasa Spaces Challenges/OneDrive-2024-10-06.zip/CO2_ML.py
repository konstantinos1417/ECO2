import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# List of filenames and corresponding station names
filenames = ['CIT-co2.csv', 'CNP-co2.csv', 'COM-co2.csv', 'FUL-co2.csv',
             'GRA-co2.csv', 'IRV-co2.csv', 'LJO-co2.csv', 'ONT-co2.csv', 
             'SCI-co2.csv', 'USC1-co2.csv', 'VIC-co2.csv']
names = ['CIT', 'CNP', 'COM', 'FUL', 'GRA', 'IRV', 'LJO', 'ONT', 'SCI', 'USC1', 'VIC']

# Function to fill NaN values with the standard deviation of each column
def fill_na_with_std(df):
    for col in df.columns:
        df[col].fillna(df[col].std(), inplace=True)
    return df

# Loop through each station's data
for i in range(len(filenames)):
    print("MODEL FOR STATION " + names[i])
    
    # Load the data
    df = pd.read_csv(filenames[i])
    
    df = df.dropna()
    
    # Fill NaN values with the standard deviation of each column
   # df = fill_na_with_std(df)  
     
    
    # Prepare features and targets
    x = df[['mm', 'dd', 'HH']].values  # Features: month, day, hour
    y = df[['co2_ppm', 'co2_uncertainty', 'co2_min', 'co2_max']].values  # Targets
    
    # Split into train/test sets
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
    
    # Normalize features using StandardScaler
    scaler = StandardScaler()
    x_train_scaled = scaler.fit_transform(x_train)
    x_test_scaled = scaler.transform(x_test)
    
    # Define a simple neural network model
    model = Sequential()
    model.add(Dense(64, activation='relu', input_shape=(x_train_scaled.shape[1],)))  # Input layer
    model.add(Dense(64, activation='relu'))  # Hidden layer
    model.add(Dense(y_train.shape[1]))  # Output layer for multiple outputs

    # Compile the model
    model.compile(optimizer='adam', loss='mean_squared_error')

    # Train the model
    history = model.fit(x_train_scaled, y_train, epochs=100, batch_size=32, validation_split=0.2)

    # Evaluate the model on the test set
    loss = model.evaluate(x_test_scaled, y_test)
    print(f"Station {names[i]} - Test Loss (MSE): {loss}")

    # Make predictions
    y_pred = model.predict(x_test_scaled)

    # # Plot the actual vs predicted for the first target (co2_ppm) using scatter plots
    # plt.figure(figsize=(10, 6))
    # plt.scatter(range(len(y_test)), y_test[:, 0], label='Actual CO2 PPM', color='blue', alpha=0.6)
    # plt.scatter(range(len(y_pred)), y_pred[:, 0], label='Predicted CO2 PPM', color='red', alpha=0.6)
    # plt.title(f'Actual vs Predicted CO2 PPM for {names[i]}')
    # plt.xlabel('Sample Index')
    # plt.ylabel('CO2 PPM')
    # plt.legend()
    # plt.show()
    
    # Plot histograms of actual vs predicted for the first target (co2_ppm)
    plt.figure(figsize=(10, 6))
    plt.hist(y_test[:, 0], bins=20, alpha=0.5, label='Actual CO2 PPM', color='blue')
    plt.hist(y_pred[:, 0], bins=20, alpha=0.5, label='Predicted CO2 PPM', color='red')
    plt.title(f'Actual vs Predicted CO2 PPB Histogram for {names[i]}')
    plt.xlabel('CO2 PPM')
    plt.ylabel('Frequency')
    plt.legend()
    plt.show()

    # Optionally, plot the training history (loss)
    plt.figure(figsize=(10, 6))
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title(f'Training History for {names[i]}')
    plt.xlabel('Epochs')
    plt.ylabel('Loss (MSE)')
    plt.legend()
    plt.show()
