import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# List of filenames and corresponding station names
filenames = ['CIT-ch4.csv', 'CNP-ch4.csv', 'COM-ch4.csv', 'FUL-ch4.csv',
             'GRA-ch4.csv', 'IRV-ch4.csv', 'LJO-ch4.csv', 'ONT-ch4.csv', 
             'SCI-ch4.csv', 'USC1-ch4.csv', 'VIC-ch4.csv']
names = ['CIT', 'CNP', 'COM', 'FUL', 'GRA', 'IRV', 'LJO', 'ONT', 'SCI', 'USC1', 'VIC']

# Function to fill NaN values with the standard deviation of each column
def fill_na_with_std(df):
    for col in df.columns:
        df[col].fillna(df[col].std(), inplace=True)
    return df

# Loop through each station's data
for i in range(len(filenames)):
    print("MODEL FOR STATION " + names[i])
    
    # Load the data
    df = pd.read_csv(filenames[i])
    
    df = df.dropna()
    
    # Fill NaN values with the standard deviation of each column
   # df = fill_na_with_std(df)  
     
    
    # Prepare features and targets
    x = df[['mm', 'dd', 'HH']].values  # Features: month, day, hour
    y = df[['ch4_ppb','ch4_uncertainty','ch4_min','ch4_max']].values  # Targets
    

    # Split into train/test sets
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
    
    # Normalize features using StandardScaler
    scaler = StandardScaler()
    x_train_scaled = scaler.fit_transform(x_train)
    x_test_scaled = scaler.transform(x_test)
    
    # Define a simple neural network model
    model = Sequential()
    model.add(Dense(128, activation='relu', input_shape=(x_train_scaled.shape[1],)))  # Input layer
    model.add(Dense(64, activation='relu'))  # Hidden layer
    model.add(Dense(y_train.shape[1]))  # Output layer for multiple outputs

    # Compile the model
    model.compile(optimizer='adam', loss='mean_squared_error')

    # Train the model
    history = model.fit(x_train_scaled, y_train, epochs=100, batch_size=32, validation_split=0.2)

    # Evaluate the model on the test set
    loss = model.evaluate(x_test_scaled, y_test)
    print(f"Station {names[i]} - Test Loss (MSE): {loss}")

    # Make predictions
    y_pred = model.predict(x_test_scaled)

    # Plot the actual vs predicted for the first target (co2_ppm) using scatter plots
    # plt.figure(figsize=(10, 6))
    # plt.scatter(range(len(y_test)), y_test[:, 0], label='Actual CH4 PPM', color='blue', alpha=0.6)
    # plt.scatter(range(len(y_pred)), y_pred[:, 0], label='Predicted CH4 PPM', color='red', alpha=0.6)
    # plt.title(f'Actual vs Predicted CH4 PPB for {names[i]}')
    # plt.xlabel('Sample Index')
    # plt.ylabel('CH4 PPB')
    # plt.legend()
    # plt.show()

    # Plot histograms of actual vs predicted for the first target (ch4_ppb)
    plt.figure(figsize=(10, 6))
    plt.hist(y_test[:, 0], bins=20, alpha=0.5, label='Actual CH4 PPB', color='blue')
    plt.hist(y_pred[:, 0], bins=20, alpha=0.5, label='Predicted CH4 PPB', color='red')
    plt.title(f'Actual vs Predicted CH4 PPB Histogram for {names[i]}')
    plt.xlabel('CH4 PPB')
    plt.ylabel('Frequency')
    plt.legend()
    plt.show()
    
    # Optionally, plot the training history (loss)
    plt.figure(figsize=(10, 6))
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title(f'Training History for {names[i]}')
    plt.xlabel('Epochs')
    plt.ylabel('Loss (MSE)')
    plt.legend()
    plt.show()
